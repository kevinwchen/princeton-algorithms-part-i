/* *****************************************************************************
 *  Name:              Kevin Chen
 *  Coursera User ID:  123456
 *  Last modified:     March 11, 2023
 **************************************************************************** */

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
