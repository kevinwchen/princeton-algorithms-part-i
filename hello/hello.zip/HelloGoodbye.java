/* *****************************************************************************
 *  Name:              Kevin Chen
 *  Coursera User ID:  123456
 *  Last modified:     March 11, 2023
 **************************************************************************** */

public class HelloGoodbye {
    public static void main(String[] args) {
        String nameOne = args[0];
        String nameTwo = args[1];

        System.out.println("Hello " + nameOne + " and " + nameTwo + ".");
        System.out.println("Goodbye " + nameTwo + " and " + nameOne + ".");
    }
}
